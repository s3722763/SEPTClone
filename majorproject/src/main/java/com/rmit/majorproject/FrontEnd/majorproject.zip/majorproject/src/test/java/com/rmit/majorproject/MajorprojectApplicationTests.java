package com.rmit.majorproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MajorprojectApplicationTests {

    @Test
    void contextLoads() {
    }

}
